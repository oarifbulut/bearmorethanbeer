AppViewX.CertPlus.Installer is the Windows Agent Gateway installer and will enable communication between AppViewX and windows machine across network. 
The ServerCertificateGateway.pfx and ClientCertificateGateway.pfx will be the default certificate which will be installed as part of Agent installation process which
will be later replaced and managed by AppViewX

AppViewX.CertPlus.Troubleshooter.msi is a compatibility checker application and will be used for validating all the pre-requisites required before installing the agent

To check binding, follow the below steps
Run all Commands in Command prompt
Default port is 8999.

To show certificate bound to Windows gateway:
netsh http show sslcert ipport=0.0.0.0:8999

To delete certificate bound to Windows gateway:
netsh http delete sslcert ipport=0.0.0.0:8999

To get Server certificate thumbprint(Execute in powershell):
Get-ChildItem -path Cert:\LocalMachine\My -dnsname "*<CommonName>*"

To bind a new certificate to Windows gateway:
$AppId = [Guid]::NewGuid().Guid
netsh http add sslcert ipport=0.0.0.0:8999 certhash=ba08609ca0edb3742e7bd921f537f50b5ba147b0 appid=`{$AppId`} clientcertnegotiation=enable

If the agent is already installed then navigate to "Add or Remove Program" and Uninstall AppViewX.CertPlus.Service/AppViewX.CertPlus.Installer and Install the AppViewX.CertPlus.Installer from the current folder.


